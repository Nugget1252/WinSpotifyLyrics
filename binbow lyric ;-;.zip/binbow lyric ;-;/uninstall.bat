@echo off
title Lyrics Widget Uninstaller
color 0C
cls

echo ====================================================
echo             WARNING: REMOVING LYRICS WIDGET...
echo ====================================================
echo.
echo This will completely remove the lyrics tracker from your PC.
echo.
set /p "cleanup=Are you sure you want to uninstall? (Y/N): "
if /i "%cleanup%" neq "Y" exit

echo.
echo [1/3] Killing active backend background server...
taskkill /f /im python.exe >nul 2>&1

echo [2/3] Removing automatic boot triggers...
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if exist "%STARTUP_DIR%\LaunchLyricsServer.vbs" (
    del /f /q "%STARTUP_DIR%\LaunchLyricsServer.vbs" >nul
)

echo [3/3] Removing layer folder from Lively Wallpaper...
set "LIVELY_PATH=%USERPROFILE%\AppData\Local\Lively Wallpaper\Library\wallpapers\LivelyLyricsUI"
if exist "%LIVELY_PATH%" (
    rmdir /s /q "%LIVELY_PATH%" >nul
)

echo.
echo ====================================================
echo REMOVAL COMPLETE! The widget has been wiped clean.
echo ====================================================
echo.
pause
