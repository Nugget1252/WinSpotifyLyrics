from flask import Flask, request, jsonify
from flask_cors import CORS
import cutlet
from deep_translator import GoogleTranslator
import hashlib
import copy
import json
import os
import requests
import re
import asyncio
from winsdk.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as SessionManager

app = Flask(__name__)
CORS(app)

katsu = cutlet.Cutlet()
katsu.use_foreign_spelling = False
eng_translator = GoogleTranslator(source='auto', target='en')

CACHE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lyrics_cache.json')

def load_cache():
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error reading cache file: {e}")
    return {}

def save_cache(cache_data):
    try:
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error writing to cache file: {e}")

TRANSLATION_CACHE = load_cache()

def get_cache_key(lyrics_data):
    raw_text = ""
    for item in lyrics_data:
        if isinstance(item, dict) and 'text' in item:
            raw_text += item['text']
        elif isinstance(item, str):
            raw_text += item
    return hashlib.md5(raw_text.encode('utf-8')).hexdigest()

def fetch_and_parse_lrc(track, artist):
    url = "https://lrclib.net/api/get"
    params = {'track_name': track, 'artist_name': artist}
    try:
        r = requests.get(url, params=params, timeout=5)
        if r.status_code == 200:
            lrc_text = r.json().get('syncedLyrics')
            if not lrc_text: return None
            parsed_lyrics = []
            pattern = re.compile(r'\[(\d{2,}):(\d{2}\.\d{2,3})\](.*)')
            for line in lrc_text.split('\n'):
                match = pattern.match(line)
                if match:
                    mins = int(match.group(1))
                    secs = float(match.group(2))
                    text = match.group(3).strip()
                    if text:
                        parsed_lyrics.append({"time": (mins * 60) + secs, "text": text})
            return parsed_lyrics
    except Exception as e:
        print(f"LRCLIB Fetch Error: {e}")
    return None

def get_windows_media_position():
    try:
        async def async_get_pos():
            manager = await SessionManager.request_async()
            session = manager.get_current_session()
            if session:
                timeline = session.get_timeline_properties()
                return timeline.position.total_seconds()
            return 0.0
        return asyncio.run(async_get_pos())
    except Exception as e:
        return 0.0

@app.route('/time', methods=['GET'])
def get_time():
    return jsonify({'position': get_windows_media_position()})

@app.route('/convert', methods=['POST'])
def convert():
    data = request.json.get('lyrics', [])
    mode = request.json.get('mode', 'romaji')
    track = request.json.get('track', '')
    artist = request.json.get('artist', '')

    if data: song_id = get_cache_key(data)
    elif track and artist: song_id = hashlib.md5(f"{track}_{artist}".lower().encode('utf-8')).hexdigest()
    else: return jsonify({'lyrics': []})

    if song_id not in TRANSLATION_CACHE: TRANSLATION_CACHE[song_id] = {}
    if mode in TRANSLATION_CACHE[song_id]: return jsonify({'lyrics': TRANSLATION_CACHE[song_id][mode]})

    if not data:
        if 'kanji' in TRANSLATION_CACHE[song_id]: data = TRANSLATION_CACHE[song_id]['kanji']
        else:
            data = fetch_and_parse_lrc(track, artist)
            if not data: return jsonify({'lyrics': [{"time": 0, "text": "No lyrics found on Spotify or Web."}]})
            TRANSLATION_CACHE[song_id]['kanji'] = copy.deepcopy(data)
            save_cache(TRANSLATION_CACHE)
        if mode == 'kanji': return jsonify({'lyrics': data})

    processed_data = copy.deepcopy(data)
    for i in range(len(processed_data)):
        text = processed_data[i]['text'] if isinstance(processed_data[i], dict) else processed_data[i]
        if text.strip():
            if mode == 'english':
                try: result = eng_translator.translate(text)
                except: result = text
            else:
                try: result = katsu.romaji(text)
                except: result = text

            if isinstance(processed_data[i], dict): processed_data[i]['text'] = result
            else: processed_data[i] = result

    TRANSLATION_CACHE[song_id][mode] = processed_data
    save_cache(TRANSLATION_CACHE)
    return jsonify({'lyrics': processed_data})

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080)
