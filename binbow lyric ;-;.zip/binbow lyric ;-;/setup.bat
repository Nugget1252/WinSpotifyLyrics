@echo off
title Lyrics Widget Installer
color 0A
cls

:: Force execution inside the active directory folder instead of C:\Windows\System32
cd /d "%~dp0"

echo ====================================================
echo             RUNNING AUTOMATIC INSTALLER...
echo ====================================================
echo.

:: 1. Check for Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo [ERROR] Python is not installed or not added to PATH!
    echo Please install Python and make sure to check "Add Python to PATH".
    echo.
    pause
    exit
)

:: 2. Install modern requirements (Compatible with Python 3.13+)
echo [1/3] Installing background layout requirements...
pip install flask flask-cors cutlet deep-translator requests winrt-runtime winrt-Windows.Media.Control --quiet
if %errorlevel% neq 0 (
    color 0C
    echo [ERROR] Standard installation failed. Attempting fallback method...
    pip install flask flask-cors cutlet deep-translator requests winrt-runtime winrt-Windows.Media.Control
)

:: 3. Link to Lively Wallpaper
echo [2/3] Linking layout folder to Lively Wallpaper...
set "LIVELY_PATH=%USERPROFILE%\AppData\Local\Lively Wallpaper\Library\wallpapers"
if exist "%LIVELY_PATH%" (
    if not exist "%LIVELY_PATH%\LivelyLyricsUI" (
        xcopy /E /I /Y "LivelyLyricsUI" "%LIVELY_PATH%\LivelyLyricsUI" >nul
    )
)

:: 4. Create Background Startup task
echo [3/3] Setting up automatic startup task...
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "SCRIPT_PATH=%~dp0romaji_server.py"
set "VBS_LAUNCHER=%STARTUP_DIR%\LaunchLyricsServer.vbs"

echo CreateObject("Wscript.Shell").Run "python """%SCRIPT_PATH%"""", 0, False > "%VBS_LAUNCHER%"

echo.
echo ====================================================
echo SUCCESS! Installation is complete.
echo.
echo 1. Close this window.
echo 2. LOG OUT of Windows and log back in (or restart your PC).
echo 3. Open Lively Wallpaper and select "Spotify Translated Lyrics"!
echo ====================================================
echo.
pause
